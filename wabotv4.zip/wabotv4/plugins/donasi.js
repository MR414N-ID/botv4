let handler = async m => m.reply(`
╭─「 Donasi • Pulsa • Gopay • Dana • Ovo 」
│ • Kirim ke [0882292838634]
╰────
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
